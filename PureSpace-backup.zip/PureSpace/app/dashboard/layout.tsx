"use client";

import Link from "next/link";
import Image from "next/image";
import AIAssistantButton from "@/app/components/AIAssistantButton";

import { usePathname, useRouter } from "next/navigation";

import {
  LayoutDashboard,
  Building2,
  Users,
  CalendarDays,
  Receipt,
  FileText,
  UserRound,
  LogOut,
  Wrench,
} from "lucide-react";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({
  children,
}: DashboardLayoutProps) {
  const pathname = usePathname();
  const router = useRouter();

  function handleLogout() {
    router.replace("/office-login");
  }

  function menuItem(
    href: string,
    label: string,
    icon: React.ReactNode
  ) {
    const active =
      pathname === href ||
      (href !== "/dashboard" &&
        pathname.startsWith(`${href}/`));

    return (
      <Link
        href={href}
        className={`group relative flex items-center gap-4 rounded-2xl px-5 py-3.5 transition-all duration-300 ${
          active
            ? "bg-white text-[#1F4E79] shadow-lg"
            : "text-blue-100 hover:bg-white/10 hover:text-white"
        }`}
      >
        {active && (
          <div className="absolute bottom-2 top-2 left-0 w-1 rounded-r-full bg-[#61C6D9]" />
        )}

        <div
          className={`transition ${
            active ? "text-[#2E7BBE]" : ""
          }`}
        >
          {icon}
        </div>

        <span className="font-semibold">
          {label}
        </span>
      </Link>
    );
  }

  return (
    <div className="flex min-h-screen bg-[#F4F7FB]">
      <aside className="flex w-[270px] shrink-0 flex-col bg-[#1F4E79] text-white shadow-2xl">
        <div className="border-b border-white/10 px-7 py-7">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white shadow-lg">
              <Image
                src="/images/logo.jpg"
                alt="PureSpace"
                width={46}
                height={46}
                className="rounded-xl"
              />
            </div>

            <div>
              <h1 className="text-2xl font-extrabold">
                PureSpace
              </h1>

              <p className="text-xs text-blue-200">
                Office Dashboard
              </p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-5 py-7">
          <p className="mb-3 px-3 text-[11px] uppercase tracking-[0.3em] text-blue-200">
            Main
          </p>

          <div className="space-y-1.5">
            {menuItem(
              "/dashboard",
              "Dashboard",
              <LayoutDashboard className="h-5 w-5" />
            )}

            {menuItem(
              "/dashboard/receipts",
              "Receipts",
              <Receipt className="h-5 w-5" />
            )}

            {menuItem(
              "/dashboard/invoices",
              "Invoices",
              <FileText className="h-5 w-5" />
            )}
          </div>

          <p className="mb-3 mt-8 px-3 text-[11px] uppercase tracking-[0.3em] text-blue-200">
            Operations
          </p>

          <div className="space-y-1.5">
            {menuItem(
              "/dashboard/properties",
              "Properties",
              <Building2 className="h-5 w-5" />
            )}

            {menuItem(
              "/dashboard/team",
              "Employees",
              <Users className="h-5 w-5" />
            )}

{menuItem(
  "/dashboard/calendar",
  "Calendar & Bookings",
  <CalendarDays className="h-5 w-5" />
)}

            {menuItem(
              "/dashboard/schedule",
              "Schedule",
              <CalendarDays className="h-5 w-5" />
            )}

            {menuItem(
              "/dashboard/maintenance",
              "Maintenance",
              <Wrench className="h-5 w-5" />
            )}
          </div>

          <p className="mb-3 mt-8 px-3 text-[11px] uppercase tracking-[0.3em] text-blue-200">
            Clients
          </p>

          <div className="space-y-1.5">
            {menuItem(
              "/owner-home",
              "Owner Portal",
              <UserRound className="h-5 w-5" />
            )}
          </div>
        </nav>

        <div className="border-t border-white/10 p-5">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-[#163A5A] font-bold">
              S
            </div>

            <div>
              <p className="font-semibold">
                Sara Lopez
              </p>

              <p className="text-xs text-blue-200">
                Office Admin
              </p>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="flex w-full items-center justify-center gap-3 rounded-2xl bg-red-500 py-3 font-semibold text-white transition hover:bg-red-600"
          >
            <LogOut className="h-5 w-5" />
            Logout
          </button>
        </div>
      </aside>

      <main className="min-w-0 flex-1 overflow-y-auto">
        {children}
      </main>
      <AIAssistantButton />
    </div>
  );
}
